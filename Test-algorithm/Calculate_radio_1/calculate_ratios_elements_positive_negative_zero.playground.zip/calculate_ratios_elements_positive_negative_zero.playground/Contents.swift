func plusMinus(arr: [Int]) -> [Any]? {
    //...
    //... do something
    //...
    return nil
}

let input1 = [-1, -1, 0 , 1, 1]
_ = plusMinus(arr: input1)

let input2 = [-4, 3, -9, 0, 4, 1]
_ = plusMinus(arr: input2)
